import cv2
from detectron2 import model_zoo
from detectron2.config import get_cfg
from detectron2.engine import DefaultPredictor
from detectron2.data import MetadataCatalog
from detectron2.utils.visualizer import Visualizer, ColorMode
from detectron2.utils.video_visualizer import VideoVisualizer
import math
import numpy as np

# Function to select keypoints
def select_keypoints(instances, frame):
    #Total keypoints are 17
    selected_keypoints = [5, 6, 7, 8, 11, 12, 13, 14]
    keypoints_hsv = []

    for keypoints in instances.pred_keypoints:
        hsv_per_keypoint = []
        xy_per_keypoint = []
        for idx in selected_keypoints:
            x, y, _ = keypoints[idx]
            # Ensure the coordinates are within the frame boundaries
            if 0 <= int(x) < frame.shape[1] and 0 <= int(y) < frame.shape[0]:
                # Get BGR value at the (x, y) coordinate
                bgr_color = frame[int(y), int(x)].astype(np.uint8).reshape(1, 1, 3)
                # Convert BGR to HSV
                hsv_color = cv2.cvtColor(bgr_color, cv2.COLOR_BGR2HSV)[0][0]
                # Append HSV values to the list
                hsv_per_keypoint.extend(hsv_color)
                hsv_per_keypoint.append(x)
                hsv_per_keypoint.append(y)

        keypoints_hsv.append(hsv_per_keypoint)

    return keypoints_hsv


# Function to track objects based on proximity
def track_objects(tracking_objects, keypoints_hsv):
    # Iterate through existing tracked objects
    if tracking_objects:
        for obj_id, hsv2 in list(tracking_objects.items()):
            object_exists = False
            # Iterate through current frame's center points
            for hsv1 in keypoints_hsv:
                # Calculate distance between points
                #distance = math.hypot(pt2[0] - pt1[0], pt2[1] - pt1[1])
                difference_hsv=0
                difference_xy=0
                count=0
                for i in range(40):
                    if count<3:
                        difference_hsv += abs(int(hsv2[i]) - int(hsv1[i]))
                    elif count==3:
                        difference_xy += abs(int(hsv2[i]) - int(hsv1[i]))
                    elif count==4:
                        difference_xy += abs(int(hsv2[i]) - int(hsv1[i]))
                        count=0
                        continue;
                    count += 1
                # Update tracked object's position if within a threshold distance
                if difference_hsv <= 960 and difference_xy<=240:
                    tracking_objects[obj_id] = hsv1
                    object_exists = True
                    keypoints_hsv.remove(hsv1)
            # Remove objects that are no longer tracked
            if not object_exists:
                tracking_objects.pop(obj_id)
    return tracking_objects, keypoints_hsv

# Function to assign object IDs to new objects
def assign_object_ids(tracking_objects, keypoints_hsv, tracking_id):
    for hsv_value in keypoints_hsv:
        tracking_objects[tracking_id] = hsv_value
        tracking_id += 1
    return tracking_objects, tracking_id

if __name__ == "__main__":
    # Load Keypoint Detection Model
    cfg_keypoint = get_cfg()
    cfg_keypoint.MODEL.DEVICE = "cpu"
    cfg_keypoint.merge_from_file(model_zoo.get_config_file("COCO-Keypoints/keypoint_rcnn_R_50_FPN_3x.yaml"))
    cfg_keypoint.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.5
    cfg_keypoint.MODEL.WEIGHTS = model_zoo.get_checkpoint_url("COCO-Keypoints/keypoint_rcnn_R_50_FPN_3x.yaml")

    # Initialize the predictor
    predictor = DefaultPredictor(cfg_keypoint)

    # Video capture
    video = cv2.VideoCapture("./data/video-clip-3.mp4")
    fps = float(video.get(cv2.CAP_PROP_FPS))
    width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    video_out = cv2.VideoWriter("./result_Keypoint.mkv", cv2.VideoWriter_fourcc(*"x264"), fps, (width, height), True)

    # Initialize tracking variables
    tracking_objects = {}
    tracking_id = 0

    while True:
        success, frame = video.read()
        if not success:
            break

        # Run Keypoint Detection on the frame
        outputs = predictor(frame)
        instances = outputs["instances"]
        
        # Select keypoints
        keypoints_hsv = select_keypoints(instances, frame)
        
        # Track existing objects based on proximity
        tracking_objects, center_points_cframe = track_objects(tracking_objects, keypoints_hsv)

        # Assign new object IDs
        tracking_objects, tracking_id = assign_object_ids(tracking_objects, keypoints_hsv, tracking_id)

        # Display object IDs on the frame
        for obj_id, pt in tracking_objects.items():
            cv2.putText(frame, "ID: "+str(obj_id)+", Class: 0", (int(pt[3]), int(pt[4])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 69, 255), 2)
        
        
        # Initialize Visualizer
        v = Visualizer(frame[:,:,::-1], MetadataCatalog.get(cfg_keypoint.DATASETS.TRAIN[0]))
        out = v.draw_instance_predictions(instances.to("cpu"))
        #cv2.imshow("Result", out.get_image()[:, :, ::-1])
        #cv2.imshow("Object Tracking", frame)
        #video_out.write(frame)
        
        # key = cv2.waitKey(1) & 0xFF
        # if key == ord("q"):
        #     break
        video_out.write(out.get_image()[:, :, ::-1])

    print("Done")
    video_out.release()
    video.release()
