import cv2

from detectron2 import model_zoo
from detectron2.engine import DefaultPredictor
from detectron2.config import get_cfg
from detectron2.utils.visualizer import Visualizer
from detectron2.data import MetadataCatalog, DatasetCatalog
from detectron2.utils.video_visualizer import VideoVisualizer
from detectron2.utils.visualizer import ColorMode

def calculate_iou(box1, box2):
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2

    x_intersection = max(0, min(x1 + w1, x2 + w2) - max(x1, x2))
    y_intersection = max(0, min(y1 + h1, y2 + h2) - max(y1, y2))

    intersection_area = x_intersection * y_intersection
    box1_area = w1 * h1
    box2_area = w2 * h2

    iou = intersection_area / float(box1_area + box2_area - intersection_area)
    return iou

id = 0
def gen_id():
    id += 1
    return id

def calculate_iou(box1, box2):
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2

    x_intersection = max(0, min(x1 + w1, x2 + w2) - max(x1, x2))
    y_intersection = max(0, min(y1 + h1, y2 + h2) - max(y1, y2))

    intersection_area = x_intersection * y_intersection
    box1_area = w1 * h1
    box2_area = w2 * h2

    iou = intersection_area / float(box1_area + box2_area - intersection_area)
    return iou

def associate_predictions(existing_objects, predictions, iou_threshold=0.9):
    matched_objects = {}

    for pred_id, (pred_class, pred_box) in enumerate(predictions):
        max_iou = 0
        matched_id = None

        for object_id, (obj_class, obj_box) in existing_objects.items():
            if obj_class == pred_class:
                iou = calculate_iou(obj_box, pred_box)
                if iou > max_iou:
                    max_iou = iou
                    matched_id = object_id

        if matched_id is not None and max_iou > iou_threshold:
            matched_objects[pred_id] = matched_id
        else:
            matched_objects[pred_id] = None

    return matched_objects

def update_existing_objects(existing_objects, predictions, matched_objects):
    for pred_id, (pred_class, pred_box) in enumerate(predictions):
        matched_id = matched_objects[pred_id]

        if matched_id is not None:
            existing_objects[matched_id] = (pred_class, pred_box)
        else:
            new_id = max(existing_objects.keys()) + 1 if existing_objects else 0
            existing_objects[new_id] = (pred_class, pred_box)

    return existing_objects

def main():
    cfg = get_cfg()
    cfg.MODEL.DEVICE = "cpu"
    # add project-specific config (e.g., TensorMask) here if you're not running a model in detectron2's core library
    cfg.merge_from_file(model_zoo.get_config_file("COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml"))
    cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.5  # set threshold for this model
    # Find a model from detectron2's model zoo. You can use the https://dl.fbaipublicfiles... url as well
    cfg.MODEL.WEIGHTS = model_zoo.get_checkpoint_url("COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml")

    existing_objects = {}

    predictor = DefaultPredictor(cfg)

    video = cv2.VideoCapture("./data/video-clip-1.mp4")
    fps = float(video.get(cv2.CAP_PROP_FPS))
    width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    video_out=cv2.VideoWriter("./result.mkv", cv2.VideoWriter_fourcc(*"x264"), fps, (width, height), True)
    frame_counter = 0
    video_visualizer = VideoVisualizer(MetadataCatalog.get(cfg.DATASETS.TRAIN[0]), ColorMode.IMAGE)
    while True:
        frame_counter += 1
        success, frame = video.read()
        if not success:
            break
        print(frame_counter)
        outputs = predictor(frame)
        instances = outputs["instances"]

        out = video_visualizer.draw_instance_predictions(frame, instances.to("cpu"))
        video_out.write(out.get_image()[:, :, ::-1])
    print("Done")
    video_out.release()
    video.release()


if __name__ == "__main__":
    main()
